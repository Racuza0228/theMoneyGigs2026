// lib/refreshable_page.dart
abstract class RefreshablePage {
  Future<void> refreshPageData();
}